﻿using System.ComponentModel.DataAnnotations;

namespace CarRentalFinal.Models
{
    public class User
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }
    public class LoginRequest
    {
        [Required] public string Phone { get; set; } = string.Empty;
        [Required] public string Password { get; set; } = string.Empty;
    }
}