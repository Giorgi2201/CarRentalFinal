﻿using Microsoft.AspNetCore.Mvc;
using CarRentalFinal.Models;

namespace CarRentalFinal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        [HttpPost("register")]
        public IActionResult Register([FromBody] User newUser)
        {
            return Ok(new
            {
                message = "Success!",
                user = newUser.FirstName
            });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            using var httpClient = new HttpClient();
            try
            {
                var response = await httpClient.PostAsJsonAsync(
                    "https://rentcar.stepprojects.ge/api/Users/Login",
                    new
                    {
                        phoneNumber = request.Phone, // Changed to match API
                        password = request.Password
                    }
                );

                if (response.IsSuccessStatusCode)
                {
                    var responseBody = await response.Content.ReadAsStringAsync();
                    return Ok(new { token = responseBody });
                }

                return Unauthorized("Login failed - check phone/password");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }
    }
}